@echo off
title CheapHDR - Ambient Light Bridge
cd /d "%~dp0"

echo [1/3] Closing DX Light if running...
taskkill /IM "DX Light.exe" /F >nul 2>&1

echo [2/3] Checking HyperHDR...
tasklist /FI "IMAGENAME eq hyperhdr.exe" 2>NUL | find /I /N "hyperhdr.exe">NUL
if "%ERRORLEVEL%"=="1" (
    if exist "C:\Program Files\HyperHDR\bin\hyperhdr.exe" (
        echo Starting HyperHDR background service...
        start "" "C:\Program Files\HyperHDR\bin\hyperhdr.exe"
    )
)

if not exist "bin\CheapHDR.exe" (
    echo [INFO] Binary not found. Building now...
    call build.bat
)

echo [3/3] Starting CheapHDR...
echo ==========================================================
echo           CheapHDR - Universal Light Bridge
echo ==========================================================
echo Listening on UDP 127.0.0.1:2801 for 63 LEDs.
echo Close this window to stop the bridge.
echo.
"bin\CheapHDR.exe" %*
pause
