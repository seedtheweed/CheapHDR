Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)

' 1. Terminate competing DX Light software silently
WshShell.Run "taskkill /IM ""DX Light.exe"" /F", 0, True

' 2. Check if HyperHDR is already running; if not, start it
hyperHdrPath = "C:\Program Files\HyperHDR\bin\hyperhdr.exe"
If fso.FileExists(hyperHdrPath) Then
    Set objWMIService = GetObject("winmgmts:\\.\root\cimv2")
    Set colProcesses = objWMIService.ExecQuery("Select * from Win32_Process Where Name = 'hyperhdr.exe'")
    If colProcesses.Count = 0 Then
        WshShell.Run """" & hyperHdrPath & """", 0, False
    End If
End If

' 3. Ensure CheapHDR binary exists
exePath = scriptDir & "\bin\CheapHDR.exe"
If Not fso.FileExists(exePath) Then
    WshShell.Run """" & scriptDir & "\build.bat""", 0, True
End If

' 4. Launch CheapHDR silently in background (0 = hidden window)
WshShell.Run """" & exePath & """", 0, False
