@echo off
title Stop CheapHDR
echo Stopping CheapHDR processes...
taskkill /IM CheapHDR.exe /F >nul 2>&1
taskkill /IM HyperHDR_Robobloq_Bridge.exe /F >nul 2>&1
taskkill /IM HyperHDR_Bridge.exe /F >nul 2>&1
echo Done! CheapHDR is stopped.
ping 127.0.0.1 -n 2 >nul
