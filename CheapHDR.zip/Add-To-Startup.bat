@echo off
title Add CheapHDR to Windows Startup
cd /d "%~dp0"

set "TARGET_VBS=%CD%\Start-CheapHDR-Hidden.vbs"

echo ==========================================================
echo          Add CheapHDR to Windows Startup
echo ==========================================================
echo Target: %TARGET_VBS%
echo.

powershell -NoProfile -Command "$startup = [Environment]::GetFolderPath('Startup'); $old = Join-Path $startup 'HyperHDR-Bridge.lnk'; if (Test-Path $old) { Remove-Item $old -Force }; $ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut(Join-Path $startup 'CheapHDR.lnk'); $s.TargetPath = 'wscript.exe'; $s.Arguments = '\"%TARGET_VBS%\"'; $s.WorkingDirectory = '%CD%'; $s.Description = 'CheapHDR Ambient Light Bridge'; $s.Save()"

if %errorlevel% equ 0 (
    echo.
    echo [SUCCESS] CheapHDR has been added to Windows Startup!
    echo It will now run silently in the background whenever Windows boots.
) else (
    echo.
    echo [ERROR] Failed to create startup shortcut.
)

echo.
pause
