@echo off
title Remove CheapHDR from Windows Startup
cd /d "%~dp0"

echo ==========================================================
echo       Remove CheapHDR from Windows Startup
echo ==========================================================
echo.

powershell -NoProfile -Command "$startup = [Environment]::GetFolderPath('Startup'); $path = Join-Path $startup 'CheapHDR.lnk'; $old = Join-Path $startup 'HyperHDR-Bridge.lnk'; if (Test-Path $old) { Remove-Item $old -Force }; if (Test-Path $path) { Remove-Item $path -Force; Write-Output '[SUCCESS] CheapHDR shortcut removed from Windows Startup!' } else { Write-Output '[INFO] No CheapHDR startup shortcut was found.' }"

echo.
pause
