# CheapHDR 🌈

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Platform: Windows](https://img.shields.io/badge/Platform-Windows%2010%20%7C%2011-blue.svg)](https://microsoft.com)
[![Dependencies](https://img.shields.io/badge/Dependencies-Zero%20(Pure%20.NET)-brightgreen.svg)]()

> **Cinema-grade HyperHDR ambient backlighting for practically ANY budget USB WS2812B LED strip.**  
> No soldering microcontrollers. No flashing WLED. No headaches.

---

## 💡 Why CheapHDR?

You bought an inexpensive $15–$25 USB monitor backlight kit on Amazon or AliExpress (like **Robobloq**, **DX-Light**, **SyncLight**, or generic Chinese USB ambient light strips). 

You plug it in, and the manufacturer's software is terrible:
- **Violent Strobing in Movies:** It doesn't detect black bars (21:9 letterboxing), causing lights to flash violently between 0% and 100% brightness.
- **Harsh Jerky Transitions:** No smoothing filters, making camera pans and campfire flickers look like a strobe light.
- **Bloatware:** Heavy background apps that waste CPU and RAM.

**HyperHDR** completely fixes all of this with real-time DirectX 11 capture, HDR tone mapping, automatic movie black-bar removal, and smooth ambient blooms. **However, HyperHDR cannot talk to these cheap USB light controllers out of the box.** People usually tell you to cut wires, buy an ESP32, solder microcontrollers, and flash WLED.

**CheapHDR is the plug-and-play bridge:** It connects HyperHDR directly to your USB light strip in the background with zero hardware modification and sub-millisecond response time.

---

## ⚡ 60-Second Setup Guide

### 1. Download This:
1. Click the green **`<> Code`** button at the top of this GitHub page and select **`Download ZIP`** (or download `CheapHDR.zip` from the [Releases](https://github.com/YOUR_USERNAME/CheapHDR/releases) tab).
2. Extract the ZIP folder anywhere on your PC (e.g. `C:\CheapHDR` or your Documents folder).

### 2. Close Any Old Software:
If you had manufacturer software running (like `DX Light`, `SyncLight`, or `Ambibox`), **completely exit/close it** from your Windows system tray so it doesn't fight for the USB port.

### 3. Click This:
* Double-click **`Start-CheapHDR.bat`**.

### 4. What Happens Next:
* **CheapHDR** automatically detects your USB light strip (whether it's a USB-HID strip like Robobloq/DX-Light or a USB Serial Adalight strip) across any USB port.
* It starts a local high-speed loopback bridge on `127.0.0.1:2801`.
* It waits for HyperHDR's color stream and starts lighting up your strip!

---

## ⚙️ 2-Minute HyperHDR Setup (One-Time)

Download and open [HyperHDR](https://github.com/awawa-dev/HyperHDR/releases) (in your browser at **`http://localhost:8090`**):

1. **Set Controller:**
   * Go to **LED Hardware** $\rightarrow$ **LED Controller**.
   * **Controller type:** Select **`udpraw`**.
   * **Target IP:** `127.0.0.1`
   * **Port:** `2801`
   * **LED count:** Enter your strip's total LED count (default is `63` for standard 27" monitor strips).
   * *Click **Save settings**.*

2. **Set Monitor LED Layout:**
   * Go to **LED Hardware** $\rightarrow$ **LED Layout**.
   * Enter the number of LEDs on each side of your monitor (e.g., Top: `29`, Left: `17`, Right: `17`, Bottom: `0`).
   * Choose your starting corner and direction (Clockwise / Counter-Clockwise).
   * *Click **Save settings**.*

3. **Turn On Movie Anti-Strobe (The Fix!):**
   * Go to **Image Processing**:
     * **Black Border Detection:** Check **Enable** *(Threshold: `5%`)*.  
       *(This automatically ignores widescreen movie black bars so your lights never flicker).*
     * **Smoothing:** Check **Enable** *(Settling time: `160ms` – `220ms`)*.  
       *(Turns harsh flickers into smooth, luxurious ambient blooms).*
     * **Update frequency:** Set to **`30Hz`** *(optimal 30 FPS, near-zero CPU usage)*.
   * *Click **Save settings**.*

4. **Turn On Output:**
   * On the **Overview** dashboard, turn **System Screen Capture** $\rightarrow$ **ON** 🟢, **LED Device** $\rightarrow$ **ON** 🟢, and turn **USB Capture** $\rightarrow$ **OFF** 🔴.
   * Click the top-right master power button to **ON** 🟢.

**Your lights will now mirror your screen smoothly!**

---

## 🚀 Make It 100% Automatic on PC Boot

You don't want to click buttons every time you turn on your PC.

* Double-click **`Add-To-Startup.bat`**.
* **What happens:** CheapHDR will now launch **completely silently in the background** (with zero visible windows) whenever you start your computer.

---

## 🛑 How to Deactivate or Turn It Off

Whenever you want to pause, stop, or remove CheapHDR:

* **To Stop It Right Now:**  
  Double-click **`Stop-CheapHDR.bat`**. This immediately terminates the bridge process.
* **To Remove It From Auto-Boot:**  
  Double-click **`Remove-From-Startup.bat`**. This deletes the Windows startup shortcut.
* **To Turn Off Lights Temporarily:**  
  Just click the master power button in HyperHDR (`http://localhost:8090`), or turn off the screen.

---

## 📁 What Each File Does (In Plain English)

| File | What It Does | When To Use It |
|---|---|---|
| **`Start-CheapHDR.bat`** | Launches the bridge with a black command window displaying real-time FPS and USB connection status. | Use this for first-time testing or troubleshooting. |
| **`Start-CheapHDR-Hidden.vbs`** | Launches the bridge silently in the background without any visible window. | Use this for normal day-to-day operation. |
| **`Add-To-Startup.bat`** | Creates a Windows Startup shortcut to run CheapHDR silently on computer boot. | Run this once if you want your lights to work automatically every day. |
| **`Remove-From-Startup.bat`** | Removes CheapHDR from Windows Startup. | Run this if you don't want it starting automatically anymore. |
| **`Stop-CheapHDR.bat`** | Cleanly closes and kills all running CheapHDR background processes. | Use this when you want to shut the bridge down completely. |
| **`build.bat`** | Compiles `src\Program.cs` into `bin\CheapHDR.exe` using Windows' built-in .NET compiler. | Use this if you modified the code or want to compile your own binary with zero dependencies. |

---

## 🔌 Supported Hardware

CheapHDR is designed to work with practically any budget USB monitor backlight kit:

1. **USB-HID Ambient Kits (QinHeng / WCH `VID 0x1A86, PID 0xFE07`):**
   * Robobloq Quiklight / SyncLight
   * DX-Light
   * Generic Amazon & AliExpress ambient monitor kits
2. **USB-to-Serial WS2812B Strips (Adalight Protocol):**
   * Arduino Nano / Uno / Pro Micro kits
   * CH340, CP2102, FT232, and Raspberry Pi Pico serial controllers

CheapHDR automatically detects which type of hardware is connected across any USB port.

---

## 🛠️ Advanced Command-Line Flags

If you run the binary manually or configure custom batch shortcuts:
```text
CheapHDR.exe [-p port] [-l leds] [-d device] [-c com] [-b baud]
```
- `-p, --port <port>` : UDP listen port for HyperHDR (default: `2801`)
- `-l, --leds <count>` : Total number of LEDs (default: `63`)
- `-d, --device <mode>` : Hardware mode: `auto` (default), `hid`, or `serial`
- `-c, --com <port>` : COM port for serial strips (e.g. `COM3`)
- `-b, --baud <rate>` : Serial baud rate (default: `115200`)

---

## 📜 License

This project is licensed under the [MIT License](LICENSE). Free for personal and commercial use.
