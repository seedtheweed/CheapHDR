@echo off
setlocal
cd /d "%~dp0"

echo ========================================================
echo                 Building CheapHDR Bridge
echo ========================================================
echo.

set "CSC=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"

if not exist "%CSC%" (
    set "CSC=C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe"
)

if not exist "bin" mkdir bin

echo Compiling src\Program.cs with full optimizations...
"%CSC%" /nologo /optimize+ /target:exe /out:"bin\CheapHDR.exe" "src\Program.cs"

if %errorlevel% equ 0 (
    echo.
    echo [BUILD SUCCESS] Binary ready at bin\CheapHDR.exe!
) else (
    echo.
    echo [BUILD FAILED] Compilation failed with error code %errorlevel%
)
echo.
