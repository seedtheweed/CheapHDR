using System;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Microsoft.Win32.SafeHandles;

namespace CheapHDR {
    class Program {
        // --- Win32 Kernel32 API ---
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern SafeFileHandle CreateFile(
            string lpFileName,
            uint dwDesiredAccess,
            uint dwShareMode,
            IntPtr lpSecurityAttributes,
            uint dwCreationDisposition,
            uint dwFlagsAndAttributes,
            IntPtr hTemplateFile
        );

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool WriteFile(
            SafeFileHandle hFile,
            byte[] lpBuffer,
            uint nNumberOfBytesToWrite,
            out uint lpNumberOfBytesWritten,
            IntPtr lpOverlapped
        );

        // --- Win32 SetupAPI & HID API for Device Auto-Discovery ---
        [DllImport("hid.dll", SetLastError = true)]
        private static extern void HidD_GetHidGuid(out Guid hidGuid);

        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern IntPtr SetupDiGetClassDevs(
            ref Guid classGuid,
            string enumerator,
            IntPtr hwndParent,
            uint flags
        );

        [DllImport("setupapi.dll", SetLastError = true)]
        private static extern bool SetupDiEnumDeviceInterfaces(
            IntPtr hDevInfo,
            IntPtr devInfo,
            ref Guid interfaceClassGuid,
            uint memberIndex,
            ref SP_DEVICE_INTERFACE_DATA deviceInterfaceData
        );

        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern bool SetupDiGetDeviceInterfaceDetail(
            IntPtr hDevInfo,
            ref SP_DEVICE_INTERFACE_DATA deviceInterfaceData,
            IntPtr deviceInterfaceDetailData,
            uint deviceInterfaceDetailDataSize,
            out uint requiredSize,
            IntPtr deviceInfoData
        );

        [DllImport("setupapi.dll", SetLastError = true)]
        private static extern bool SetupDiDestroyDeviceInfoList(IntPtr hDevInfo);

        [StructLayout(LayoutKind.Sequential)]
        private struct SP_DEVICE_INTERFACE_DATA {
            public uint cbSize;
            public Guid interfaceClassGuid;
            public uint flags;
            public IntPtr reserved;
        }

        private const uint GENERIC_WRITE = 0x40000000;
        private const uint FILE_SHARE_READ = 0x00000001;
        private const uint FILE_SHARE_WRITE = 0x00000002;
        private const uint OPEN_EXISTING = 3;
        private const uint DIGCF_PRESENT = 0x02;
        private const uint DIGCF_DEVICEINTERFACE = 0x10;

        // --- Configuration & State ---
        private static int listenPort = 2801;
        private static int targetLedCount = 63;
        private static string targetMode = "auto"; // "auto", "hid", "serial"
        private static string serialPortName = null;
        private static int serialBaudRate = 115200;

        private static string activeDeviceType = null; // "hid" or "serial"
        private static SafeFileHandle hidHandle = null;
        private static SerialPort serialPort = null;
        private static string activeDevicePath = null;
        private static byte seqId = 1;

        private static void Log(string message) {
            try {
                Console.WriteLine(message);
            } catch { }

            try {
                string logFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CheapHDR.log");
                File.AppendAllText(logFile, string.Format("[{0:HH:mm:ss}] {1}\r\n", DateTime.Now, message));
            } catch { }
        }

        /// <summary>
        /// Automatically discovers connected Robobloq/DX-Light USB HID controllers.
        /// Searches for VID 0x1A86, PID 0xFE07, Interface MI_00 across all USB ports.
        /// </summary>
        public static string FindHidDevicePath() {
            Guid hidGuid;
            HidD_GetHidGuid(out hidGuid);

            IntPtr devInfo = SetupDiGetClassDevs(ref hidGuid, null, IntPtr.Zero, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);
            if (devInfo == IntPtr.Zero || devInfo.ToInt64() == -1) return null;

            try {
                SP_DEVICE_INTERFACE_DATA ifData = new SP_DEVICE_INTERFACE_DATA();
                ifData.cbSize = (uint)Marshal.SizeOf(ifData);

                for (uint i = 0; SetupDiEnumDeviceInterfaces(devInfo, IntPtr.Zero, ref hidGuid, i, ref ifData); i++) {
                    uint reqSize = 0;
                    SetupDiGetDeviceInterfaceDetail(devInfo, ref ifData, IntPtr.Zero, 0, out reqSize, IntPtr.Zero);

                    if (reqSize > 0) {
                        IntPtr detailBuffer = Marshal.AllocHGlobal((int)reqSize);
                        try {
                            int cbSize = IntPtr.Size == 8 ? 8 : 4 + Marshal.SystemDefaultCharSize;
                            Marshal.WriteInt32(detailBuffer, cbSize);

                            if (SetupDiGetDeviceInterfaceDetail(devInfo, ref ifData, detailBuffer, reqSize, out reqSize, IntPtr.Zero)) {
                                IntPtr pDevicePath = new IntPtr(detailBuffer.ToInt64() + 4);
                                string path = Marshal.PtrToStringAuto(pDevicePath);
                                if (!string.IsNullOrEmpty(path)) {
                                    string pLower = path.ToLower();
                                    if (pLower.Contains("vid_1a86") && pLower.Contains("pid_fe07") && pLower.Contains("mi_00")) {
                                        return path;
                                    }
                                }
                            }
                        } finally {
                            Marshal.FreeHGlobal(detailBuffer);
                        }
                    }
                }
            } finally {
                SetupDiDestroyDeviceInfoList(devInfo);
            }

            return null;
        }

        private static bool OpenDevice() {
            CloseDevice();

            // Mode 1: Check for USB HID strip if allowed
            if (targetMode == "auto" || targetMode == "hid") {
                activeDevicePath = FindHidDevicePath();
                if (!string.IsNullOrEmpty(activeDevicePath)) {
                    hidHandle = CreateFile(
                        activeDevicePath,
                        GENERIC_WRITE,
                        FILE_SHARE_READ | FILE_SHARE_WRITE,
                        IntPtr.Zero,
                        OPEN_EXISTING,
                        0,
                        IntPtr.Zero
                    );

                    if (!hidHandle.IsInvalid) {
                        activeDeviceType = "hid";
                        Log("[CheapHDR] Connected to USB HID light strip: " + activeDevicePath);
                        return true;
                    }
                }
            }

            // Mode 2: Check for USB Serial (Adalight / Arduino / WS2812B COM port)
            if (targetMode == "auto" || targetMode == "serial") {
                string[] ports = SerialPort.GetPortNames();
                string chosenPort = serialPortName;

                if (string.IsNullOrEmpty(chosenPort) && ports.Length > 0) {
                    chosenPort = ports[0]; // Auto-select first available COM port
                }

                if (!string.IsNullOrEmpty(chosenPort)) {
                    try {
                        serialPort = new SerialPort(chosenPort, serialBaudRate);
                        serialPort.Open();
                        activeDeviceType = "serial";
                        Log(string.Format("[CheapHDR] Connected to Serial LED controller on {0} @ {1} baud", chosenPort, serialBaudRate));
                        return true;
                    } catch (Exception ex) {
                        Log(string.Format("[CheapHDR] Failed to open {0}: {1}", chosenPort, ex.Message));
                    }
                }
            }

            Log("[CheapHDR] No compatible USB LED strip found yet. Waiting for device...");
            return false;
        }

        private static void CloseDevice() {
            if (hidHandle != null && !hidHandle.IsInvalid && !hidHandle.IsClosed) {
                hidHandle.Close();
                hidHandle = null;
            }
            if (serialPort != null && serialPort.IsOpen) {
                serialPort.Close();
                serialPort = null;
            }
            activeDeviceType = null;
        }

        /// <summary>
        /// Builds Robobloq / DX-Light HID setSyncScreen packet.
        /// </summary>
        private static byte[] BuildHidPacket(byte[] rgbData, int ledsToSend) {
            int payloadLen = ledsToSend * 5;
            int totalLen = 7 + payloadLen;
            byte[] packet = new byte[totalLen];

            packet[0] = 0x53; // 'S'
            packet[1] = 0x43; // 'C'
            packet[2] = (byte)((totalLen >> 8) & 0xFF);
            packet[3] = (byte)(totalLen & 0xFF);
            packet[4] = seqId++;
            if (seqId == 0) seqId = 1;
            packet[5] = 0x80; // setSyncScreen command (128)

            for (int i = 0; i < ledsToSend; i++) {
                byte ledIndex = (byte)(i + 1);
                int offset = 6 + (i * 5);
                byte r = 0, g = 0, b = 0;

                if (i * 3 + 2 < rgbData.Length) {
                    r = rgbData[i * 3 + 0];
                    g = rgbData[i * 3 + 1];
                    b = rgbData[i * 3 + 2];
                }

                packet[offset + 0] = ledIndex; // Start LED
                packet[offset + 1] = r;
                packet[offset + 2] = g;
                packet[offset + 3] = b;
                packet[offset + 4] = ledIndex; // End LED
            }

            int sum = 0;
            for (int i = 0; i < totalLen - 1; i++) {
                sum += packet[i];
            }
            packet[totalLen - 1] = (byte)(sum % 256);

            return packet;
        }

        /// <summary>
        /// Builds standard Adalight serial packet ('Ada' + count + checksum + RGB payload).
        /// </summary>
        private static byte[] BuildAdalightPacket(byte[] rgbData, int ledsToSend) {
            int count = ledsToSend - 1;
            byte hi = (byte)((count >> 8) & 0xFF);
            byte lo = (byte)(count & 0xFF);
            byte check = (byte)(hi ^ lo ^ 0x55);

            byte[] packet = new byte[6 + ledsToSend * 3];
            packet[0] = (byte)'A';
            packet[1] = (byte)'d';
            packet[2] = (byte)'a';
            packet[3] = hi;
            packet[4] = lo;
            packet[5] = check;

            int copyLen = Math.Min(rgbData.Length, ledsToSend * 3);
            Array.Copy(rgbData, 0, packet, 6, copyLen);

            return packet;
        }

        private static bool SendToDevice(byte[] rgbData, int ledsToSend) {
            if (activeDeviceType == null) {
                if (!OpenDevice()) return false;
            }

            if (activeDeviceType == "hid") {
                byte[] packet = BuildHidPacket(rgbData, ledsToSend);
                const int chunkSize = 64;
                int numChunks = (packet.Length + chunkSize - 1) / chunkSize;
                byte[] report = new byte[65]; // Report ID 0x00 + 64 bytes

                for (int c = 0; c < numChunks; c++) {
                    int offset = c * chunkSize;
                    int len = Math.Min(chunkSize, packet.Length - offset);

                    Array.Clear(report, 0, 65);
                    report[0] = 0x00; // Report ID
                    Array.Copy(packet, offset, report, 1, len);

                    uint written;
                    bool ok = WriteFile(hidHandle, report, 65, out written, IntPtr.Zero);
                    if (!ok) {
                        int err = Marshal.GetLastWin32Error();
                        Log(string.Format("[CheapHDR] Write failed (Error {0}). Reconnecting...", err));
                        OpenDevice();
                        return false;
                    }
                }
                return true;
            } else if (activeDeviceType == "serial") {
                try {
                    byte[] packet = BuildAdalightPacket(rgbData, ledsToSend);
                    serialPort.Write(packet, 0, packet.Length);
                    return true;
                } catch (Exception ex) {
                    Log(string.Format("[CheapHDR] Serial write failed: {0}. Reconnecting...", ex.Message));
                    OpenDevice();
                    return false;
                }
            }

            return false;
        }

        public static void Main(string[] args) {
            AppDomain.CurrentDomain.UnhandledException += delegate(object sender, UnhandledExceptionEventArgs e) {
                Log("FATAL UNHANDLED EXCEPTION: " + (e.ExceptionObject != null ? e.ExceptionObject.ToString() : "null"));
            };
            AppDomain.CurrentDomain.ProcessExit += delegate(object sender, EventArgs e) {
                Log("PROCESS EXIT TRIGGERED");
            };

            Log("==========================================================");
            Log("          CheapHDR - Universal Ambient Light Bridge       ");
            Log("   Cinema-Grade HyperHDR Screen Sync for Budget USB Strips");
            Log("==========================================================");

            for (int i = 0; i < args.Length; i++) {
                string arg = args[i].ToLower();
                if ((arg == "-p" || arg == "--port") && i + 1 < args.Length) {
                    int p;
                    if (int.TryParse(args[++i], out p)) listenPort = p;
                } else if ((arg == "-l" || arg == "--leds") && i + 1 < args.Length) {
                    int l;
                    if (int.TryParse(args[++i], out l)) targetLedCount = l;
                } else if ((arg == "-d" || arg == "--device") && i + 1 < args.Length) {
                    targetMode = args[++i].ToLower();
                } else if ((arg == "-c" || arg == "--com") && i + 1 < args.Length) {
                    serialPortName = args[++i].ToUpper();
                } else if ((arg == "-b" || arg == "--baud") && i + 1 < args.Length) {
                    int b;
                    if (int.TryParse(args[++i], out b)) serialBaudRate = b;
                } else if (arg == "-h" || arg == "--help") {
                    Log("Usage: CheapHDR.exe [-p port] [-l leds] [-d device] [-c com] [-b baud]");
                    Log("  -p, --port <port>    UDP listen port (default: 2801)");
                    Log("  -l, --leds <count>   Total LED count (default: 63)");
                    Log("  -d, --device <mode>  Device type: auto | hid | serial (default: auto)");
                    Log("  -c, --com <port>     COM port for serial strips (e.g., COM3)");
                    Log("  -b, --baud <rate>    Baud rate for serial strips (default: 115200)");
                    return;
                } else {
                    int val;
                    if (int.TryParse(args[i], out val)) {
                        if (i == 0) listenPort = val;
                        else if (i == 1) targetLedCount = val;
                    }
                }
            }

            Log(string.Format("[CheapHDR] UDP Listen Port: 127.0.0.1:{0}", listenPort));
            Log(string.Format("[CheapHDR] Configured LEDs : {0}", targetLedCount));
            Log(string.Format("[CheapHDR] Hardware Mode   : {0}", targetMode.ToUpper()));

            OpenDevice();

            UdpClient listener = null;
            try {
                listener = new UdpClient(new IPEndPoint(IPAddress.Loopback, listenPort));
                // Ignore WSAECONNRESET on Windows (prevents crash if sender isn't ready)
                const int SIO_UDP_CONNRESET = -1744830452;
                try {
                    listener.Client.IOControl((IOControlCode)SIO_UDP_CONNRESET, new byte[] { 0, 0, 0, 0 }, null);
                } catch { }
            } catch (Exception ex) {
                Log("[CheapHDR] Error binding UDP port " + listenPort + ": " + ex.Message);
                return;
            }

            IPEndPoint groupEP = new IPEndPoint(IPAddress.Any, 0);
            long frameCount = 0;
            DateTime lastLog = DateTime.Now;

            Log("[CheapHDR] Bridge is active! Waiting for HyperHDR color stream...");

            while (true) {
                try {
                    byte[] bytes = listener.Receive(ref groupEP);
                    if (bytes == null || bytes.Length == 0) continue;

                    SendToDevice(bytes, targetLedCount);

                    frameCount++;
                    if ((DateTime.Now - lastLog).TotalSeconds >= 5.0) {
                        double fps = frameCount / (DateTime.Now - lastLog).TotalSeconds;
                        Log(string.Format("[CheapHDR] Streaming - {0} frames sent (~{1:0.0} FPS)", frameCount, fps));
                        frameCount = 0;
                        lastLog = DateTime.Now;
                    }
                } catch (SocketException) {
                    // Transient UDP connection reset or interrupt, smoothly continue
                    Thread.Sleep(5);
                } catch (ThreadAbortException) {
                    break;
                } catch (Exception ex) {
                    Log("[CheapHDR] Warning: " + ex.Message);
                    Thread.Sleep(50);
                }
            }

            if (listener != null) listener.Close();
            CloseDevice();
        }
    }
}
